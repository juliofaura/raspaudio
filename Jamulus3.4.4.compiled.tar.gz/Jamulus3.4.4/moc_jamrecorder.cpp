/****************************************************************************
** Meta object code from reading C++ file 'jamrecorder.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "src/recorder/jamrecorder.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'jamrecorder.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_recorder__CJamClientConnection[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_recorder__CJamClientConnection[] = {
    "recorder::CJamClientConnection\0"
};

void recorder::CJamClientConnection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData recorder::CJamClientConnection::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject recorder::CJamClientConnection::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_recorder__CJamClientConnection,
      qt_meta_data_recorder__CJamClientConnection, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &recorder::CJamClientConnection::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *recorder::CJamClientConnection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *recorder::CJamClientConnection::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_recorder__CJamClientConnection))
        return static_cast<void*>(const_cast< CJamClientConnection*>(this));
    return QObject::qt_metacast(_clname);
}

int recorder::CJamClientConnection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_recorder__CJamClient[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_recorder__CJamClient[] = {
    "recorder::CJamClient\0"
};

void recorder::CJamClient::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData recorder::CJamClient::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject recorder::CJamClient::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_recorder__CJamClient,
      qt_meta_data_recorder__CJamClient, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &recorder::CJamClient::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *recorder::CJamClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *recorder::CJamClient::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_recorder__CJamClient))
        return static_cast<void*>(const_cast< CJamClient*>(this));
    return QObject::qt_metacast(_clname);
}

int recorder::CJamClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_recorder__CJamSession[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_recorder__CJamSession[] = {
    "recorder::CJamSession\0"
};

void recorder::CJamSession::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData recorder::CJamSession::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject recorder::CJamSession::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_recorder__CJamSession,
      qt_meta_data_recorder__CJamSession, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &recorder::CJamSession::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *recorder::CJamSession::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *recorder::CJamSession::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_recorder__CJamSession))
        return static_cast<void*>(const_cast< CJamSession*>(this));
    return QObject::qt_metacast(_clname);
}

int recorder::CJamSession::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_recorder__CJamRecorder[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      23,   33,   33,   33, 0x0a,
      34,   33,   33,   33, 0x0a,
      42,   62,   33,   33, 0x0a,
      68,  123,   33,   33, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_recorder__CJamRecorder[] = {
    "recorder::CJamRecorder\0OnStart()\0\0"
    "OnEnd()\0OnDisconnected(int)\0iChID\0"
    "OnFrame(int,QString,CHostAddress,int,CVector<int16_t>)\0"
    "iChID,name,address,numAudioChannels,data\0"
};

void recorder::CJamRecorder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        CJamRecorder *_t = static_cast<CJamRecorder *>(_o);
        switch (_id) {
        case 0: _t->OnStart(); break;
        case 1: _t->OnEnd(); break;
        case 2: _t->OnDisconnected((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->OnFrame((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const CHostAddress(*)>(_a[3])),(*reinterpret_cast< const int(*)>(_a[4])),(*reinterpret_cast< const CVector<int16_t>(*)>(_a[5]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData recorder::CJamRecorder::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject recorder::CJamRecorder::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_recorder__CJamRecorder,
      qt_meta_data_recorder__CJamRecorder, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &recorder::CJamRecorder::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *recorder::CJamRecorder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *recorder::CJamRecorder::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_recorder__CJamRecorder))
        return static_cast<void*>(const_cast< CJamRecorder*>(this));
    return QThread::qt_metacast(_clname);
}

int recorder::CJamRecorder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
